import numpy as np
import random
np.random.seed(1)
random.seed(1)
import cv2
from os import walk
from preprocessing import preprocess_image 
from os.path import join
from keras.callbacks import ModelCheckpoint, EarlyStopping
from keras.layers import Dense, Dropout, Input, Lambda, Flatten, Convolution2D, MaxPooling2D, ZeroPadding2D , LeakyReLU
from keras import backend as K
from keras.models import Sequential, Model
from keras.optimizers import  RMSprop
from keras.layers.normalization import BatchNormalization
from keras.regularizers import l2

def compute_accuracy(predictions, labels):
    """ Compute classification accuracy with a fixed threshold on distances.
    """
    return labels[predictions.ravel() < 0.1].mean()    
def euclidean_distance(vects):
    x, y = vects
    return K.sqrt(K.sum(K.square(x - y), axis=1, keepdims=True))


def eucl_dist_output_shape(shapes):
    shape1, shape2 = shapes
    return (shape1[0], 1)


def contrastive_loss(y_true, y_pred):
    '''Contrastive loss from Hadsell-et-al.'06
    http://yann.lecun.com/exdb/publis/pdf/hadsell-chopra-lecun-06.pdf
    '''

    # y_pred --> Dw, euclidean distance computed in the embedded space

    """ What you want is double the distance if the pairs are equal - 
    this is the loss for pairs should be be with "zero" distance. 
    But if the pairs are distinct from each other you want to calculate
    their distance from the margin and double it.
    """

    margin = 1

    """ Dw to be close to 0 when y_true is 1 (for positive pairs) and 
        Dw close or bigger than 1 when y_true is 0 (for negative pairs)
        Distance low for similar pairs and high for diff images
    """    
    
    return K.mean(y_true * K.square(y_pred) + (1 - y_true) * K.square(K.maximum(margin - y_pred, 0)))
   

def create_base_network_signet(input_shape):
    """ A CNN architecture for a
        Siamese Netwrok
    """ 
    
    seq = Sequential()
    seq.add(Convolution2D(96, (11, 11), activation='relu', name='conv1_1', strides=(4,4), input_shape= input_shape, 
                        kernel_initializer='glorot_uniform', data_format='channels_last'))
    seq.add(BatchNormalization(epsilon=1e-06, axis=1, momentum=0.9))
    seq.add(MaxPooling2D((3,3), strides=(2, 2)))    
    seq.add(ZeroPadding2D((2, 2),))
    
    seq.add(Convolution2D(256, (5, 5), activation='relu', name='conv2_1', strides=(1, 1), kernel_initializer='glorot_uniform'))
    seq.add(BatchNormalization(epsilon=1e-06, axis=1, momentum=0.9))
    seq.add(MaxPooling2D((3,3), strides=(2, 2)))
    seq.add(Dropout(0.3))
    seq.add(ZeroPadding2D((2, 2)))
    
    seq.add(Convolution2D(384, (3, 3), activation='relu', name='conv3_1', strides=(1, 1), kernel_initializer='glorot_uniform'))
    seq.add(ZeroPadding2D((1, 1)))
    
    seq.add(Convolution2D(256, (3, 3), activation='relu', name='conv3_2', strides=(1, 1), kernel_initializer='glorot_uniform'))    
    seq.add(MaxPooling2D((3,3), strides=(2, 2)))
    seq.add(Dropout(0.3))
    seq.add(ZeroPadding2D((1, 1)))

    seq.add(Flatten(name='flatten'))
    seq.add(Dense(1024, kernel_regularizer=l2(0.0005), activation='relu', kernel_initializer='glorot_uniform'))
    seq.add(Dropout(0.5))
    
    seq.add(Dense(128, kernel_regularizer=l2(0.0005), activation='relu', kernel_initializer='glorot_uniform')) # softmax changed to relu
    
    print (seq.summary())
    return seq


def compute_accuracy_roc(predictions, labels):
   # Compute ROC accuracy with a range of thresholds on distances.
   dmax = np.max(predictions)
   dmin = np.min(predictions)
   nsame = np.sum(labels == 1)
   ndiff = np.sum(labels == 0)
   
   step = 0.01
   max_acc = 0
   
   for d in np.arange(dmin, dmax+step, step):
       idx1 = predictions.ravel() <= d
       idx2 = predictions.ravel() > d
       
       tpr = float(np.sum(labels[idx1] == 1)) / nsame       
       tnr = float(np.sum(labels[idx2] == 0)) / ndiff
       acc = 0.5 * (tpr + tnr)       
#       print ('ROC', acc, tpr, tnr)
       
       if (acc > max_acc):
           print(d)
           max_acc = acc
           
   return max_acc

def compute_accuracy(predictions, labels):
    """ Compute classification accuracy with a fixed threshold on distances.
    """
    return labels[predictions.ravel() < 0.3].mean()


def labelling_images():
    
    # train and test folders
    train_folder = 'train'
    test_folder = 'test'
    
    # list initialization
    

   
    
    # for train data
    
    img_real = []
    label_real = []
    img_forged = []
    label_forged = []
    
    for (dirpath, dirnames, filenames) in walk(train_folder):
        if('forge' in dirpath or 'real' in dirpath):
            for filename in filenames:
                print(filename)
                if '.png' in filename:
                    image_path = join(dirpath, filename)
                    img = cv2.imread(image_path)
                    preprocessed_image =preprocess_image(img)
                    if np.any(img == None):
                        continue
                    myList =  preprocessed_image.flatten()     
                    if 'real' in dirpath:
                        img_real.append(myList)
                        if("_" in filename[9:11]):
                            label_real.append(int(filename[9:10]))
                        else:
                            label_real.append(int(filename[9:11]))
                    else:
                        img_forged.append(myList)
                        if("_" in filename[10:12]):
                            label_forged.append(int(filename[10:11]))
                        else:
                            label_forged.append(int(filename[10:12]))
                                    
    # for test data
    
    img_real_test=[]
    label_real_test=[]
    img_forged_test=[]
    label_forged_test=[]
    
    for (dirpath, dirnames, filenames) in walk(test_folder):
        if('forge' in dirpath or 'real' in dirpath):
            for filename in filenames:
                 print(filename)
                 if '.png' in filename:
                    image_path = join(dirpath, filename)
                    img = cv2.imread(image_path)                            
                    preprocessed_image =preprocess_image(img)
                    if np.any(img == None):
                        continue
                    myList =  preprocessed_image.flatten()     
                    if 'real' in dirpath:
                        img_real_test.append(myList)
                        if("_" in filename[9:11]):
                            label_real_test.append(int(filename[9:10]))
                        else:
                            label_real_test.append(int(filename[9:11]))
                    else:
                        print("forged")
                        img_forged_test.append(myList)
                        if("_" in filename[10:12]):
                            label_forged_test.append(int(filename[10:11]))
                        else:
                            label_forged_test.append(int(filename[10:12]))
        
    return img_real,label_real,img_forged,label_forged,img_real_test,label_real_test,img_forged_test,label_forged_test
        


## getting the labels and images list
    
img_real,label_real,img_forged,label_forged,img_real_test,label_real_test,img_forged_test,label_forged_test = labelling_images()
    	


img_real = np.array(img_real)
img_forged = np.array(img_forged)
img_real_test=np.array(img_real_test)
img_forged_test=np.array(img_forged_test)
img_real = img_real.astype('float32')
img_forged = img_forged.astype('float32')
img_real_test = img_real_test.astype('float32')
img_forged_test = img_forged_test.astype('float32')
label_real = np.array(label_real)
label_forged = np.array(label_forged)
label_real_test = np.array(label_real_test)
label_forged_test = np.array(label_forged_test)

img_real /= 255
img_forged /= 255
img_real_test /= 255
img_forged_test /= 255


X_train_gen=img_real.reshape(-1,80,150,1)
X_train_for=img_forged.reshape(-1,80,150,1)
x_test_gen=img_real_test.reshape(-1,80,150,1)
x_test_for=img_forged_test.reshape(-1,80,150,1)
y_train_gen=label_real
y_train_for=label_forged
y_test_gen=label_real_test
y_test_for=label_forged_test



digit_indices_tr_gen = [np.where(y_train_gen == value)[0] for index,value in enumerate(list(set(y_train_gen)))]
digit_indices_tr_for = [np.where(y_train_for == value)[0] for index,value in enumerate(list(set(y_train_for)))]

## creating pairs 


def createst_pairs(x_gen,x_for, digit_indices_gen,digit_indices_for, nb_classes):
    """      x:         X_train, array of array of all train samples.
        digit_indices:  List of array, length = no of classes; each sublist consists of train sample indices
                        belonging to that particular class index/class
    """
    """ Positive and negative pair creation.
        Alternates between positive and negative pairs.
    """
    pairs = []
    labels = []
    
    print ('\n\n')
    print ('X_train shape:  ', x_gen.shape)
    print ('Digit_indices_gen shape:    ', np.array(digit_indices_gen).shape)
    print ('Digit_indices_for shape:    ', np.array(digit_indices_for).shape)
    print ('Length of digit indices gen:    ', len(digit_indices_gen))
    print ('Length of digit indices for:    ', len(digit_indices_for))
    print ('No of classes:  ', nb_classes)
    print ('\n\n')

    if(len(digit_indices_gen[0])==1):
        for d in range(nb_classes):
            z1, z2 = digit_indices_gen[d][0], digit_indices_tr_gen[d][1]
            pairs += [[x_gen[z1], x_gen[z2]]]
            z1, z2 = digit_indices_for[d][0], digit_indices_gen[d][0]
            pairs += [[x_for[z1], x_gen[z2]]]
            labels += [1, 0]
        return np.array(pairs), np.array(labels)
    else:
        for d in range(nb_classes):
           for i in range(len(digit_indices_gen[d])-1):
               z1, z2 = digit_indices_gen[d][i], digit_indices_gen[d][i+1]
               pairs += [[x_gen[z1], x_gen[z2]]]
               z1, z2 = digit_indices_for[d][i], digit_indices_gen[d][i+1]
               pairs += [[x_for[z1], x_gen[z2]]]
               labels += [1, 0]    
        return np.array(pairs), np.array(labels)



train_pairs, train_y = createst_pairs(X_train_gen,X_train_for, digit_indices_tr_gen,digit_indices_tr_for, len(list(set(y_train_gen))))

digit_indices_test_gen = [np.where(y_test_gen == value)[0] for index,value in enumerate(list(set(y_test_gen)))]
digit_indices_test_for = [np.where(y_test_for == value)[0] for index,value in enumerate(list(set(y_test_for)))]
test_pairs, test_y = createst_pairs(x_test_gen,x_test_for,digit_indices_test_gen,digit_indices_test_for,len(list(set(y_test_gen))))


for d in range(len(digit_indices_tr_gen)):    
        # 5 instances of each class in training data    
        print('No. of instances for class %d:   %d'%(d,len(list(digit_indices_tr_gen[d]))))
        


for d in range(len(digit_indices_tr_for)):    
        # 5 instances of each class in training data    
        print('No. of instances for class %d:   %d'%(d,len(list(digit_indices_tr_for[d]))))


        
# network definition
base_network = create_base_network_signet((80,150,1))

input_a = Input(shape=(80,150,1))
input_b = Input(shape=(80,150,1))

# because we re-use the same instance `base_network`,

# the weights of the network will be shared across the two branches


processed_a = base_network(input_a)
processed_b = base_network(input_b)

distance = Lambda(euclidean_distance, output_shape=eucl_dist_output_shape)([processed_a, processed_b])

model = Model(inputs=[input_a, input_b], outputs=distance)

# compile model
rms = RMSprop(lr=1e-4, rho=0.9, epsilon=1e-08)

# save best weights
checkpointer = ModelCheckpoint(filepath='./model/signature_siamese_cedar_1.h5', verbose=1, save_best_only=True)
early_stopping = EarlyStopping(monitor='val_loss', patience=5, verbose=1, mode='auto')
model.compile(loss=contrastive_loss, optimizer=rms,metrics=['accuracy'])


model_json = model.to_json()
with open("./model/signature_model.json", "w") as json_file:
    json_file.write(model_json)
    
    
model.fit([train_pairs[:, 0], train_pairs[:, 1]], train_y, batch_size=130, epochs=50,validation_data=([test_pairs[:, 0], test_pairs[:, 1]], test_y),callbacks=[checkpointer,early_stopping],
                    verbose=1)


test_pred = model.predict([test_pairs[:, 0], test_pairs[:, 1]])




test_acc = compute_accuracy_roc(test_pred, test_y)


print('* Accuracy on test set: %0.2f%%' % (100 * test_acc))




